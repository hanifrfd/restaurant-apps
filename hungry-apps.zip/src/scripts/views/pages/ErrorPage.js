const ErrorPage = {
  async render() {
    return `
            <div id="mainContent">
                <div class="headline">Halaman tidak ditemukan</div>                  
            </div>
        `;
  },
};

export default ErrorPage;
